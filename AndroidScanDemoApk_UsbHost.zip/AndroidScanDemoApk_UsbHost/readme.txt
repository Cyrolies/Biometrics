* USB host mode is supported in Android 3.1 and higher.

* This apk is built for Android 4.0 and higher.

* System requirement:

1. Has an USB Host port

2. Has internal or external storage and mounted as "/mnt/sdcard", need to make directory "Android" under it, look as: "/mnt/sdcard/Android". It is used by the libftrScanAPI.so, the Android application needs to add the permission in file "AndroidManifest.xml" as below:
     <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>


* Getting started 

Make sure that your Android meets the requirements, and install the test application as below steps

1. Copy the file "FtrScanDemoUsbHost.apk" to the sdcard
2. In the Android, "Settings->Application settings", check the "Unknown sources" checkbox.
3. Explore the sdcard and click the "FtrScanDemoUsbHost.apk" to install the app.
4. Plug-in the fingerprint scanner and try to capture image from it.
